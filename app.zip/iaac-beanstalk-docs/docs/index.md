# Elastic Beanstalk

## O que é o AWS Elastic Beanstalk?

## Infraestrutura

<figure markdown>
  ![Image title](assets/img/diagrama.png){ width="600" }
</figure>

