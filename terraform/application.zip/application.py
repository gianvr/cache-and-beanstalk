import os
from flask import Flask, request
import redis

# Redis connection
endpoint = os.environ['REDIS_ENDPOINT']

# Connect to Redis
redis_client = redis.Redis(host=endpoint, port=6379)

# print a nice greeting.
def say_hello(username = "World"):
    return '<p>Hello %s!</p>\n' % username

# some bits of text for the page.
header_text = '''
    <html>\n<head> <title>EB Flask Test</title> </head>\n<body>'''
instructions = '''
    <p>Para colocar algo no cache basta fazer uma requisição
    com o método POST na rota /store com o body da seguinte forma:</p>
    <p>key: [chave] </p>
    <p>value: [valor]</p>
    <p>Para retornar o valor a partir da chave faça uma requisição
    com o método GET na rota: /retrieve/[key] , sendo key a chave do valor no cache,
    sem os colchetes.</p>\n'''
footer_text = '</body>\n</html>'

# EB looks for an 'application' callable by default.
application = Flask(__name__)

# add a rule for the index page.
application.add_url_rule('/', 'index', (lambda: header_text +
    say_hello() + instructions + footer_text))

# path to store data in cache
@application.route('/store', methods=['POST'])
def store():
    value = request.form['value']
    key = request.form['key']
    redis_client.set(key, value)
    return f"Stored {value} in {key}"

# path to retrieve data from cache
@application.route('/retrieve/<key>', methods=['GET'])
def retrieve(key):
    value = redis_client.get(key)
    if value:
        return f"Retrieved {value} from {key}"
    return f"Key {key} not found"

# run the app.
if __name__ == "__main__":
    application.run()